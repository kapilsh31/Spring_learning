package com.example.demo.common;

public interface Coach {

    String getDailyWorkout();
}
