package com.example.demo.common;

public class SwimCoach implements  Coach{
    @Override
    public String getDailyWorkout() {
        return "Swim 100 m daily ";
    }
}
